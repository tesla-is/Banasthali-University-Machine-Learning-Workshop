import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

dataset = pd.read_csv('dataset/DemographicData.csv') 
X = dataset.iloc[:, 2].values
y = dataset.iloc[:, 3].values
z = dataset.iloc[:, 4].values

from sklearn.preprocessing import LabelEncoder
l = LabelEncoder()
z = l.fit_transform(z)

l.classes_

plt.scatter(X[z == 0], y[z == 0], c = "r", label = "High Income")
plt.scatter(X[z == 1], y[z == 1], c = "g", label = "Low Income")
plt.scatter(X[z == 2], y[z == 2], c = "b", label = "Lower Middle Income")
plt.scatter(X[z == 3], y[z == 3], c = "cyan", label = "Upper Middle Income")
plt.xlabel('Birth Rate')
plt.ylabel('Internet Users')
plt.legend()
plt.title('A case study to depict the relationship between Birth Rate and Internet Users')
plt.show()



